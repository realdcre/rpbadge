RICH PRESENCE BY DERCREEPER

RP needs to Run in the Background!!!

To Install, Unpack the RichPresence.zip anywhere
Execute Installer.bat
Follow Instructions
Delete Installer.bat
Launch via RichPresence.bat