RICH PRESENCE BY DERCREEPER

This is a little Script enabling you to show a StarWars fan Badge on Discord. For that, RP needs to Run in the Background!!!

To Install, Unpack the RichPresence.zip anywhere
Execute Installer.bat
Follow Instructions
Delete Installer.bat
Launch via RichPresence.bat